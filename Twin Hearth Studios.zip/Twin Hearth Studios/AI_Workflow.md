AI Workflow:

For this dashboard, I used AI on two occasions.

1. I used Copilot to find out whether I could access CSV files stored on GitHub without downloading them.

2. I used Claude to create an HTML example for my dashboard. I provided the METRIC_BRIEF.md file and a screenshot of my Power BI dashboard. I then used the generated HTML as the foundation for what I am delivering. This was very helpful because it explained the reasoning behind the dashboard's organization, and the structure made sense to me.

This was the answer from Claude:

The top ~15% of the screen is a horizontal strip of 3–4 large KPI callouts: company Q2 net revenue, YoY growth %, revenue per paying player, and paying player count. These answer questions 1 (total), 5, and 6 at a glance — the numbers the CFO scans first.

Below that, the page splits into two columns. The left column is the "money in, money out" column: a compact table for Q2 revenue by title (question 1), and beneath it a small paired block showing December settlement and December refunds (questions 2 & 3) — these are small numbers that don't need charts, just clear labels. The right column is the "studio" column: a bar or horizontal bar chart of studio revenue for FY2026 (question 4), with Twin Hearth's bar segmented or expanded inline to show its title split (question 7). This way a studio lead's eye goes straight to the right side and finds their name.

The company total for question 4 sits as a callout above or beside the studio chart, physically separated so it doesn't get confused with any single studio's number — which is exactly the "same slide" problem the brief calls out.

Why it might work: The CFO reads left-to-right across the top and is done. Studio leads scan the right column for their name. The settlement/refund numbers are tucked away but findable. Nothing is a "card."